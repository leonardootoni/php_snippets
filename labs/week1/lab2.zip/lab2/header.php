<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="main.css">
    <title>Form App</title>
</head>
<body>
    <header>
        <div class="header">
            <img src="https://www.formassembly.com/content/uploads/2018/01/Drag-and-Drop_Website-Icon_large.png" width="110" height="60" alt="Logo image form">
            <span class="title-header">My Company Inc.</span>
        </div>
    </header>
