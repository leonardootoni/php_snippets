<?php require_once "header.php"?>
<main>
    <h2>The form was successfuly submited</h2>
</main>
<?php require_once "footer.php"?>
