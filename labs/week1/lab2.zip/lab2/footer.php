<footer>
    <div>This is the footer</div>
</footer>
    
</body>
</html>
